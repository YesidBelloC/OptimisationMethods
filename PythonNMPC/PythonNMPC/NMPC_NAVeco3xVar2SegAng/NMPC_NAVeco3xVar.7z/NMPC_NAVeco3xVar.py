import numpy as np
import matplotlib.pyplot as plt
from casadi import *
from casadi.tools import *
import pdb
import sys
sys.path.append('C:/Users/crybelloceferin/Documents/MATLAB/BoubacarDIALLO/PythonController/NMPC_NAVeco3xVar')
import do_mpc

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import time

from modelNAVeco import modelNAVeco
from mpcNAVeco import mpcNAVeco
from simulatorNAVeco import simulatorNAVeco

#Information:  https://www.do-mpc.com/en/latest/index.html

""" User settings: """
show_animation = False
store_results = False

"""
Get configured do-mpc modules:
"""

model = modelNAVeco()
mpc = mpcNAVeco(model)
simulator = simulatorNAVeco(model)
estimator = do_mpc.estimator.StateFeedback(model)



"""
Set initial state
"""
time_start = time.process_time()

X_0 = 0.0
V_0 = 0.0
E_0 = 0.0
x0 = np.array([X_0, V_0, E_0])

xs = []
vs = []
es = []
us = [0]

xs.append(float(x0[0]))
vs.append(float(x0[1]))
es.append(float(x0[2]))

mpc.x0 = x0
simulator.x0 = x0
estimator.x0 = x0

mpc.set_initial_guess()

"""
Run MPC main loop:
"""

for k in range(50):
    u0 = mpc.make_step(x0)
    y_next = simulator.make_step(u0)
    x0 = estimator.make_step(y_next)

    xs.append(float(x0[0]))
    vs.append(float(x0[1]))
    es.append(float(x0[2]))
    us.append(float(u0[0]))

time_elapsed = (time.process_time() - time_start)
print(time_elapsed)


plt.figure(figsize=(10,4))
plt.plot(xs)
#plt.fill_between(DistCum,theta_vals_int,alpha=0.1)
plt.ylabel("Distance (m)")
plt.xlabel("Temps (s)")
plt.grid()
plt.show()

plt.figure(figsize=(10,4))
plt.plot(vs)
#plt.fill_between(DistCum,theta_vals_int,alpha=0.1)
plt.ylabel("Vitesse (m/s)")
plt.xlabel("Temps (s)")
plt.grid()
plt.show()

plt.figure(figsize=(10,4))
plt.plot(es)
#plt.fill_between(DistCum,theta_vals_int,alpha=0.1)
plt.ylabel("Energie (Ws)")
plt.xlabel("Temps (s)")
plt.grid()
plt.show()

plt.figure(figsize=(10,4))
plt.plot(us)
#plt.fill_between(DistCum,theta_vals_int,alpha=0.1)
plt.ylabel("Couple (Nm)")
plt.xlabel("Temps (s)")
plt.grid()
plt.show()